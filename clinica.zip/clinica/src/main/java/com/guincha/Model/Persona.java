package com.guincha.Model;

public interface Persona {

	    String getNombre();
	    void setNombre(String nombre);

	    String getCedula();
	    void setCedula(String cedula);

	    String getEmail();
	    void setEmail(String email);

	    String getCelular();
	    void setCelular(String celular);
	
}
